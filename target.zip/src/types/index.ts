// src/types/index.ts

export type PaymentMode = 'cash' | 'installment';

export interface Instructor {
  id: string;
  name: string;
  imageUrl: string; // مسیر عکس در پوشه public/images
}

export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: Instructor;
  grade: 'چهارم' | 'پنجم' | 'ششم';
  schedule: string;
  basePrice: number; // قیمت نقدی به تومان
  installmentsCount: 4 | 6; // تعداد مراحل پرداخت قسطی
  coverImage: string;
}

// تایپ داده‌های ارسالی به Supabase (استفاده از snake_case برای تطابق با دیتابیس)
export interface RegistrationRequest {
  course_id: string;
  phone_number: string;
  payment_mode: PaymentMode;
  created_at?: string;
}
