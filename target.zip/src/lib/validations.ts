import { z } from 'zod';

/** Accepts 09xxxxxxxxx and +989xxxxxxxxx (Iranian mobile formats). */
export const iranianMobileRegex = /^(?:\+98|09)9\d{8}$/;

/** Normalizes +98xxxxxxxxxx to 09xxxxxxxxxx. */
export function normalizeMobile(value: string): string {
  const trimmed = value.replace(/[\s-]/g, '');
  if (/^\+989\d{8}$/.test(trimmed)) return '0' + trimmed.slice(3);
  return trimmed;
}

export const registrationSchema = z.object({
  courseId: z
    .string()
    .min(1, { message: 'انتخاب دوره الزامی است.' }),

  studentName: z
    .string()
    .trim()
    .max(120, { message: 'نام دانش‌آموز حداکثر ۱۲۰ کاراکتر است.' })
    .optional()
    .or(z.literal('')),

  phoneNumber: z
    .string()
    .trim()
    .min(1, { message: 'وارد کردن شماره موبایل الزامی است.' })
    .regex(iranianMobileRegex, {
      message: 'شماره موبایل معتبر نیست (مثال: 09123456789 یا +989123456789).',
    })
    .transform(normalizeMobile),

  registrationType: z
    .enum(['in_person', 'online'], {
      required_error: 'لطفاً نوع برگزاری را انتخاب کنید.',
      invalid_type_error: 'نوع برگزاری نامعتبر است.',
    }),

  paymentMode: z
    .enum(['cash', 'installment'], {
      required_error: 'لطفاً نحوه پرداخت (نقدی یا اقساطی) را انتخاب کنید.',
      invalid_type_error: 'نحوه پرداخت نامعتبر است.',
    }),
});

export type RegistrationFormValues = z.infer<typeof registrationSchema>;
