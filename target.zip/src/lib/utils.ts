// src/lib/utils.ts

import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
export function formatPrice(price: number): string {
  return new Intl.NumberFormat('fa-IR').format(price) + ' تومان';
}

/**
 * محاسبه مبالغ اقساطی با احتساب ۲۰ درصد سود
 * @param basePrice قیمت نقدی و پایه دوره
 * @param months تعداد مراحل پرداخت (۴ یا ۶)
 */
export function calculateInstallment(basePrice: number, months: number) {
  const totalInstallmentPrice = basePrice * 1.2;
  const paymentPerStep = totalInstallmentPrice / months;
  return {
    total: totalInstallmentPrice,
    perStep: paymentPerStep,
  };
}