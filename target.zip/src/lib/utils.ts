import { ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { Course, InstallmentPlan, Installment, RegistrationType } from '@/src/types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPrice(value: number | null | undefined): string {
  if (value == null || Number.isNaN(Number(value))) return '—';
  return new Intl.NumberFormat('fa-IR').format(Number(value));
}

const INSTALLMENT_LABELS = [
  'پیش‌پرداخت',
  'یک ماه بعد از ثبت‌نام',
  'دو ماه بعد از ثبت‌نام',
  'سه ماه بعد از ثبت‌نام',
  'چهار ماه بعد از ثبت‌نام',
  'پنج ماه بعد از ثبت‌نام',
  'شش ماه بعد از ثبت‌نام',
  'هفت ماه بعد از ثبت‌نام',
  'هشت ماه بعد از ثبت‌نام',
  'نه ماه بعد از ثبت‌نام',
  'ده ماه بعد از ثبت‌نام',
  'یازده ماه بعد از ثبت‌نام',
];

/**
 * Phase 1 installment calculation:
 * - The ORIGINAL price is split across the installments.
 * - The discount percentage is applied per installment.
 * - Interest is applied to the (original, pre-discount) amount, consistent
 *   with the previous behavior where interest was computed on the full price.
 * Falls back to the discounted selling price when the original price is unknown.
 */
export function calculateInstallment(
  basePrice: number,
  months: number,
  interestPct = 20,
  discountPct = 0,
  originalPrice?: number | null,
): InstallmentPlan {
  const n = Math.max(1, Math.round(Number(months)));
  const interest = Number(interestPct) || 0;
  const discount = Math.min(Math.max(Number(discountPct) || 0, 0), 100);
  const base = Number(originalPrice ?? basePrice) || Number(basePrice) || 0;
  // per-installment share of the original price, discount applied per installment
  const perShare = base / n;
  const per = Math.round(perShare * (1 - discount / 100) * (1 + interest / 100));
  const total = per * n;
  const items: Installment[] = Array.from({ length: n }, (_, i) => ({
    label: INSTALLMENT_LABELS[i] ?? `${i + 1} ماه بعد از ثبت‌نام`,
    amount: per,
  }));
  return { total, perInstallment: per, items };
}

export function getBasePrice(course: Course, type: RegistrationType): number {
  return type === 'in_person' ? course.priceInPerson : course.priceOnline;
}

/** Original (pre-discount) price; falls back to the current price when unknown. */
export function getOriginalPrice(course: Course, type: RegistrationType): number {
  const original =
    type === 'in_person' ? course.originalPriceInPerson : course.originalPriceOnline;
  return original ?? getBasePrice(course, type);
}

export function getDiscountPercent(course: Course, type: RegistrationType): number {
  return type === 'in_person'
    ? course.discountPercentInPerson
    : course.discountPercentOnline;
}

/** Convenience helper used by the UI (Phase 1: pricing only, no modal redesign). */
export function calculateInstallmentPlan(
  course: Course,
  type: RegistrationType,
): InstallmentPlan {
  return calculateInstallment(
    getBasePrice(course, type),
    getInstallmentMonths(course),
    getInterestPercent(course),
    getDiscountPercent(course, type),
    getOriginalPrice(course, type),
  );
}

export function getInstallmentMonths(course: Course): number {
  return course.installmentsCount;
}

export function getInterestPercent(course: Course): number {
  return course.installmentInterestPct;
}

export function formatDuration(hours: number): string {
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  if (h === 0) return `${m} دقیقه`;
  if (m === 0) return `${h} ساعت`;
  return `${h}:${m.toString().padStart(2, '0')} ساعت`;
}
