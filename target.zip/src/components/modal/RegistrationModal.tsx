'use client';

import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Course } from '@/src/types';
import RegistrationForm from './RegistrationForm';

interface RegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  course: Course | null;
}

export default function RegistrationModal({ isOpen, onClose, course }: RegistrationModalProps) {
  // جلوگیری از اسکرول شدن صفحه اصلی وقتی مودال باز است
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!course) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* بک‌گراند تیره (Backdrop) */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm"
          />

          {/* محفظه مودال */}
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden pointer-events-auto"
              dir="rtl"
            >
              {/* هدر مودال */}
              <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50/50">
                <h2 className="text-xl font-bold text-slate-800">ثبت‌نام در دوره</h2>
                <button
                  onClick={onClose}
                  className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* بدنه مودال (فرم) */}
              <div className="p-5 md:p-6">
                <RegistrationForm 
                  course={course} 
                  onSuccess={() => {
                    // بعدا می‌توانیم اینجا یک پیام موفقیت (Toast) نشان دهیم
                    alert('ثبت‌نام شما با موفقیت انجام شد!');
                    onClose();
                  }} 
                />
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
