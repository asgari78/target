'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Course } from '@/src/types';
import { formatPrice, calculateInstallment } from '@/src/lib/utils';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import {Toggle} from '../ui/Toggle';

// اگر این اسکما را در lib/validations.ts دارید، می‌توانید از آنجا ایمپورت کنید
// در اینجا برای یکپارچگی کد، آن را تعریف کرده‌ایم
const registrationSchema = z.object({
  fullName: z.string().min(3, { message: "نام و نام خانوادگی باید حداقل ۳ حرف باشد" }),
  mobile: z.string().regex(/^09\d{9}$/, { message: "شماره موبایل نامعتبر است (مثال: 09123456789)" }),
});

type RegistrationFormData = z.infer<typeof registrationSchema>;

interface RegistrationFormProps {
  course: Course;
  onSuccess: () => void;
}

export default function RegistrationForm({ course, onSuccess }: RegistrationFormProps) {
  const [isInstallment, setIsInstallment] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<RegistrationFormData>({
    resolver: zodResolver(registrationSchema),
  });

  const onSubmit = async (data: RegistrationFormData) => {
    setIsSubmitting(true);
    setServerError(null);

    try {
      // در اینجا باید به دیتابیس Supabase متصل شوید
      // مثال: await supabase.from('registrations').insert([{ ...data, course_id: course.id, is_installment: isInstallment }])
      
      // شبیه‌سازی ریکوئست به سرور
      await new Promise((resolve) => setTimeout(resolve, 1500));
      
      console.log('Data saved:', { ...data, course: course.title, payment: isInstallment ? 'اقساط' : 'نقد' });
      onSuccess(); // بستن مودال یا نمایش پیام موفقیت
    } catch (error) {
      setServerError('خطایی در ثبت‌نام رخ داد. لطفا دوباره تلاش کنید.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // محاسبه قیمت‌ها
  const installmentDetails = calculateInstallment(course.price, course.installmentsCount || 3);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* اطلاعات دوره و انتخاب نوع پرداخت */}
      <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
        <h3 className="font-bold text-slate-800 text-lg mb-2">{course.title}</h3>
        
        <div className="flex items-center justify-between mb-4 mt-4">
          <span className="text-sm font-medium text-slate-600">نحوه پرداخت:</span>
          <Toggle 
            label="پرداخت اقساطی" 
            checked={isInstallment} 
            onChange={setIsInstallment} 
          />
        </div>

        {/* نمایش جزئیات قیمت */}
        <div className="space-y-2 border-t border-slate-200 pt-3 text-sm">
          {!isInstallment ? (
            <div className="flex justify-between items-center text-emerald-600 font-bold">
              <span>مبلغ قابل پرداخت (نقد):</span>
              <span>{formatPrice(course.price)} تومان</span>
            </div>
          ) : (
            <>
              <div className="flex justify-between text-slate-600">
                <span>پیش‌پرداخت:</span>
                <span className="font-medium">{formatPrice(installmentDetails.advancePayment)} تومان</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>مبلغ هر قسط ({installmentDetails.count} ماهه):</span>
                <span className="font-medium">{formatPrice(installmentDetails.monthlyPayment)} تومان</span>
              </div>
              <div className="flex justify-between items-center text-indigo-600 font-bold mt-2 pt-2 border-t border-slate-200 border-dashed">
                <span>مجموع پرداختی (با ۲۰٪ سود):</span>
                <span>{formatPrice(installmentDetails.totalInstallmentPrice)} تومان</span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* فیلدهای فرم */}
      <div className="space-y-4">
        <Input
          label="نام و نام خانوادگی"
          placeholder="مثال: علی رضایی"
          {...register('fullName')}
          error={errors.fullName?.message}
        />
        <Input
          label="شماره موبایل"
          type="tel"
          placeholder="09..."
          dir="ltr"
          {...register('mobile')}
          error={errors.mobile?.message}
        />
      </div>

      {serverError && (
        <p className="text-sm text-red-500 bg-red-50 p-3 rounded-lg">{serverError}</p>
      )}

      {/* دکمه ثبت */}
      <Button 
        type="submit" 
        variant="primary" 
        fullWidth 
        isLoading={isSubmitting}
      >
        تایید و ثبت‌نام اولیه
      </Button>
    </form>
  );
}
